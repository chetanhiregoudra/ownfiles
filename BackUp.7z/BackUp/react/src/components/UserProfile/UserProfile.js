import React, { Component } from 'react';

class UserProfile extends Component {
    render() {
        return(
            <h2 align="center">This is User Profile Page</h2>
        );
    };
}

export default UserProfile;