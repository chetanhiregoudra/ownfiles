import React, { Component } from 'react';

class AdminProfile extends Component {
    render() {
        return(
            <h2 align="center">This is Admin Profile Page</h2>
        );
    };
}

export default AdminProfile;