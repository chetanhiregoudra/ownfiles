import React, { Component } from 'react';

class BookList extends Component {
    render() {
        return(
            <h2 align="center">This is Book List Page</h2>
        );
    };
}

export default BookList;